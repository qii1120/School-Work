
/*
 * Auto generated Run-Time-Environment Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'Nu-LB-NUC140_TMR' 
 * Target:  'TMR' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H


/*
 * Define the Device Header File: 
 */
#define CMSIS_device_header "NUC100Series.h"



#endif /* RTE_COMPONENTS_H */
