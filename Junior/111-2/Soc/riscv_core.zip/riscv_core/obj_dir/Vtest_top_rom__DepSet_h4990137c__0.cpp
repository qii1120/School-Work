// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtest_top.h for the primary calling header

#include "verilated.h"
#include "verilated_dpi.h"

#include "Vtest_top_rom.h"

void Vtest_top_rom::writeByte(uint32_t byte_addr, uint32_t val) {
    VL_DEBUG_IF(VL_DBG_MSGF("+        Vtest_top_rom::writeByte\n"); );
    // Body
    IData/*31:0*/ unnamedblk1__DOT__t_addr;
    unnamedblk1__DOT__t_addr = 0;
    unnamedblk1__DOT__t_addr = byte_addr;
    if ((0x200000U > byte_addr)) {
        this->__PVT__mem[(0x1fffffU & unnamedblk1__DOT__t_addr)] 
            = val;
    }
}
